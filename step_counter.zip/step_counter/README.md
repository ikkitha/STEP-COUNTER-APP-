# Step Counter – Pedometer App (Flutter)

A Flutter step counter that uses the phone's motion sensor:

- Live step count in a progress ring toward your daily goal (default 6,000, editable)
- Estimated distance (km), calories burned and % of goal
- Start / Pause tracking and Reset today's count
- Last 7 days history with total, daily average and goal-reached ticks
- Steps and goal are saved on the phone, so they survive closing the app
- Works offline; no account, internet or special permissions needed

## How the counting works

The accelerometer is read ~50 times per second. `lib/services/step_detector.dart`
removes gravity, smooths the signal and counts one step each time the "bounce"
rises past a threshold (with a minimum gap between steps). It works with the phone in
a pocket, bag or hand. Distance and calories are estimates from an average stride
(0.762 m) and 0.04 kcal per step — both constants are in `lib/utils/format.dart`.

On an emulator or a device without a motion sensor, open the ⋮ menu and choose
**Add 10 test steps** to try the app.

## Build the APK on your computer

1. Install Flutter (https://docs.flutter.dev/get-started/install) and Android Studio
   (for the Android SDK). Run `flutter doctor` and fix anything it flags.
2. Open a terminal in this folder and run:

```bash
flutter create --platforms=android --project-name step_counter .
flutter pub get
flutter test                 # optional: runs the unit tests
flutter run                  # optional: test on an emulator or USB phone
flutter build apk --release
```

`flutter create .` only adds the missing `android/` folder; it does not overwrite `lib/`.

3. Your APK is at:

```
build/app/outputs/flutter-apk/app-release.apk
```

Copy it to your phone and install it (allow "install unknown apps" when asked).

## Build the APK without installing anything (GitHub Actions)

1. Push this folder to a new GitHub repository (branch `main`).
2. Open the repository's **Actions** tab, pick **Build APK** and click **Run workflow**.
3. When it finishes, download `app-release-apk` from the run's **Artifacts** section.
4. For a shareable link, upload the APK to Google Drive ("Anyone with the link") or
   attach it to a GitHub Release.

## Notes

- Steps are counted while the app is open (Android may pause sensor updates when the
  screen is off for a long time). Counting in the background all day would need the
  phone's built-in step-counter sensor plus the "Physical activity" permission.
- The release APK is signed with the debug key, which is fine for demos and sharing.
  For the Play Store you need your own keystore:
  https://docs.flutter.dev/deployment/android
