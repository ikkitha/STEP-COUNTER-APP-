import 'package:flutter/material.dart';

import '../utils/format.dart';

/// Big circular progress toward the daily goal with the step count inside.
class ProgressRing extends StatelessWidget {
  final int steps;
  final int goal;

  const ProgressRing({super.key, required this.steps, required this.goal});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final progress = goal <= 0 ? 0.0 : (steps / goal).clamp(0.0, 1.0);

    return SizedBox(
      width: 250,
      height: 250,
      child: Stack(
        alignment: Alignment.center,
        children: [
          SizedBox.expand(
            child: CircularProgressIndicator(
              value: progress,
              strokeWidth: 16,
              strokeCap: StrokeCap.round,
              backgroundColor: theme.colorScheme.primaryContainer,
            ),
          ),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.directions_walk,
                  size: 40, color: theme.colorScheme.primary),
              Text(
                formatNumber(steps),
                style: theme.textTheme.displayMedium
                    ?.copyWith(fontWeight: FontWeight.w800),
              ),
              Text('of ${formatNumber(goal)} steps'),
            ],
          ),
        ],
      ),
    );
  }
}
