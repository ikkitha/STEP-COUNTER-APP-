import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Asks for a daily step goal and pops with it (or null if cancelled).
class GoalDialog extends StatefulWidget {
  final int initial;

  const GoalDialog({super.key, required this.initial});

  @override
  State<GoalDialog> createState() => _GoalDialogState();
}

class _GoalDialogState extends State<GoalDialog> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _goal =
      TextEditingController(text: '${widget.initial}');

  @override
  void dispose() {
    _goal.dispose();
    super.dispose();
  }

  void _submit() {
    if (_formKey.currentState?.validate() ?? false) {
      Navigator.pop(context, int.parse(_goal.text.trim()));
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Daily goal'),
      content: Form(
        key: _formKey,
        child: TextFormField(
          controller: _goal,
          autofocus: true,
          keyboardType: TextInputType.number,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          decoration: const InputDecoration(
            labelText: 'Steps per day',
            border: OutlineInputBorder(),
          ),
          validator: (v) {
            final n = int.tryParse((v ?? '').trim());
            if (n == null || n < 100 || n > 100000) {
              return 'Enter a number from 100 to 100000';
            }
            return null;
          },
          onFieldSubmitted: (_) => _submit(),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        FilledButton(onPressed: _submit, child: const Text('Save')),
      ],
    );
  }
}
