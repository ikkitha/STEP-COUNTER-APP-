import 'package:flutter/material.dart';

import 'screens/home_screen.dart';
import 'state/step_store.dart';

void main() => runApp(const StepCounterApp());

class StepCounterApp extends StatefulWidget {
  /// [store] can be supplied by tests; the app creates its own otherwise.
  final StepStore? store;

  const StepCounterApp({super.key, this.store});

  @override
  State<StepCounterApp> createState() => _StepCounterAppState();
}

class _StepCounterAppState extends State<StepCounterApp>
    with WidgetsBindingObserver {
  late final StepStore _store = widget.store ?? StepStore();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _store.load().then((_) => _store.start());
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) _store.saveNow();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _store.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // StepScope sits above MaterialApp so every pushed route can reach it.
    return StepScope(
      store: _store,
      child: MaterialApp(
        title: 'Step Counter',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2E7D32)),
        ),
        home: const HomeScreen(),
      ),
    );
  }
}
