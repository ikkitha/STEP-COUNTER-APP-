import 'dart:math';

/// Turns raw accelerometer samples into step events.
///
/// 1. Take the magnitude of the acceleration vector (so phone orientation
///    does not matter).
/// 2. Subtract a slow-moving average (gravity) to keep only the bounce.
/// 3. Smooth it, then count one step each time it rises through [threshold],
///    ignoring anything closer than [minGapMs] to the previous step.
class StepDetector {
  /// Bounce strength (m/s²) needed to count as a step. Lower = more sensitive.
  static const double threshold = 1.2;

  /// Fastest believable step rate (~3.3 steps per second).
  static const int minGapMs = 300;

  double _gravity = 9.8;
  double _smooth = 0;
  bool _above = false;
  int _lastStepMs = -1000000;

  /// Feed one accelerometer sample. Returns true when it completes a step.
  bool process(double x, double y, double z, int nowMs) {
    final magnitude = sqrt(x * x + y * y + z * z);
    _gravity = 0.97 * _gravity + 0.03 * magnitude;
    _smooth = 0.6 * _smooth + 0.4 * (magnitude - _gravity);

    final rising = _smooth > threshold;
    if (rising && !_above) {
      _above = true;
      if (nowMs - _lastStepMs >= minGapMs) {
        _lastStepMs = nowMs;
        return true;
      }
    } else if (!rising && _smooth < threshold * 0.5) {
      _above = false;
    }
    return false;
  }
}
