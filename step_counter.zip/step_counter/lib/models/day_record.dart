class DayRecord {
  final DateTime date;
  final int steps;
  final bool isToday;

  const DayRecord({
    required this.date,
    required this.steps,
    required this.isToday,
  });
}
