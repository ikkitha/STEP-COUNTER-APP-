import 'package:flutter/material.dart';

import '../state/step_store.dart';
import '../utils/format.dart';
import '../widgets/goal_dialog.dart';
import '../widgets/progress_ring.dart';
import '../widgets/stat_card.dart';
import 'history_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  Future<void> _editGoal(BuildContext context) async {
    final store = StepScope.of(context);
    final goal = await showDialog<int>(
      context: context,
      builder: (_) => GoalDialog(initial: store.goal),
    );
    if (goal != null) store.setGoal(goal);
  }

  Future<void> _confirmReset(BuildContext context) async {
    final store = StepScope.of(context);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("Reset today's steps?"),
        content: const Text('Today\'s count will go back to 0.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Reset'),
          ),
        ],
      ),
    );
    if (ok == true) store.reset();
  }

  @override
  Widget build(BuildContext context) {
    final store = StepScope.of(context);
    final theme = Theme.of(context);
    final steps = store.steps;
    final goalPercent = store.goal <= 0 ? 0 : (steps * 100 ~/ store.goal);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Step Counter'),
        actions: [
          IconButton(
            tooltip: 'History',
            icon: const Icon(Icons.bar_chart),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const HistoryScreen()),
            ),
          ),
          PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'goal') _editGoal(context);
              if (value == 'test') store.addSteps(10);
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'goal', child: Text('Daily goal')),
              PopupMenuItem(value: 'test', child: Text('Add 10 test steps')),
            ],
          ),
        ],
      ),
      body: !store.loaded
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  if (store.sensorUnavailable)
                    Card(
                      color: theme.colorScheme.errorContainer,
                      child: const Padding(
                        padding: EdgeInsets.all(12),
                        child: Text(
                          'Motion sensor not available on this device. '
                          'Use the menu → "Add 10 test steps" to try the app.',
                        ),
                      ),
                    ),
                  const SizedBox(height: 8),
                  ProgressRing(steps: steps, goal: store.goal),
                  const SizedBox(height: 8),
                  Text(
                    store.tracking ? 'Tracking your steps…' : 'Paused',
                    style: theme.textTheme.bodyMedium,
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: StatCard(
                          icon: Icons.route,
                          value: '${stepsToKm(steps).toStringAsFixed(2)} km',
                          label: 'Distance',
                        ),
                      ),
                      Expanded(
                        child: StatCard(
                          icon: Icons.local_fire_department,
                          value: '${stepsToKcal(steps).round()} kcal',
                          label: 'Calories',
                        ),
                      ),
                      Expanded(
                        child: StatCard(
                          icon: Icons.flag,
                          value: '$goalPercent%',
                          label: 'Of goal',
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: FilledButton.icon(
                          onPressed: store.tracking ? store.pause : store.start,
                          icon: Icon(
                            store.tracking ? Icons.pause : Icons.play_arrow,
                          ),
                          label: Text(store.tracking ? 'Pause' : 'Start'),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () => _confirmReset(context),
                          icon: const Icon(Icons.restart_alt),
                          label: const Text('Reset'),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Carry your phone in your pocket or hand while walking. '
                    'Steps are counted while the app is open.',
                    textAlign: TextAlign.center,
                    style: theme.textTheme.bodySmall,
                  ),
                ],
              ),
            ),
    );
  }
}
