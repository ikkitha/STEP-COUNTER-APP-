import 'package:flutter/material.dart';

import '../models/day_record.dart';
import '../state/step_store.dart';
import '../utils/format.dart';

class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final store = StepScope.of(context);
    final theme = Theme.of(context);
    final days = store.history(7);
    final total = days.fold(0, (sum, d) => sum + d.steps);
    final average = total ~/ days.length;

    return Scaffold(
      appBar: AppBar(title: const Text('Last 7 days')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            color: theme.colorScheme.primaryContainer,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _Summary(label: 'Total', value: formatNumber(total)),
                  _Summary(label: 'Daily average', value: formatNumber(average)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          for (final day in days) _DayRow(day: day, goal: store.goal),
        ],
      ),
    );
  }
}

class _Summary extends StatelessWidget {
  final String label;
  final String value;

  const _Summary({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Column(
      children: [
        Text(
          value,
          style: theme.textTheme.headlineSmall
              ?.copyWith(fontWeight: FontWeight.w800),
        ),
        Text(label, style: theme.textTheme.bodySmall),
      ],
    );
  }
}

class _DayRow extends StatelessWidget {
  final DayRecord day;
  final int goal;

  const _DayRow({required this.day, required this.goal});

  @override
  Widget build(BuildContext context) {
    final progress = goal <= 0 ? 0.0 : (day.steps / goal).clamp(0.0, 1.0);
    final reached = goal > 0 && day.steps >= goal;
    final label = day.isToday ? 'Today' : kWeekdayNames[day.date.weekday - 1];

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          SizedBox(width: 52, child: Text(label)),
          Expanded(
            child: LinearProgressIndicator(
              value: progress,
              minHeight: 10,
              borderRadius: BorderRadius.circular(8),
            ),
          ),
          const SizedBox(width: 8),
          SizedBox(
            width: 60,
            child: Text(formatNumber(day.steps), textAlign: TextAlign.right),
          ),
          const SizedBox(width: 6),
          reached
              ? const Icon(Icons.check_circle, color: Colors.green, size: 18)
              : const SizedBox(width: 18),
        ],
      ),
    );
  }
}
