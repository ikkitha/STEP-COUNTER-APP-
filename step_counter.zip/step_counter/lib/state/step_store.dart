import 'dart:async';
import 'dart:convert';

import 'package:flutter/widgets.dart';
import 'package:sensors_plus/sensors_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/day_record.dart';
import '../services/step_detector.dart';
import '../utils/format.dart';

class StepStore extends ChangeNotifier {
  static const _key = 'step_counter_data';
  static const defaultGoal = 6000;
  static const _daysToKeep = 60;

  /// [sensorStream] can be replaced in tests; by default the phone's
  /// accelerometer is used.
  StepStore({Stream<AccelerometerEvent> Function()? sensorStream})
      : _sensorStream = sensorStream ??
            (() => accelerometerEventStream(
                  samplingPeriod: SensorInterval.gameInterval,
                ));

  final Stream<AccelerometerEvent> Function() _sensorStream;
  final Map<String, int> _days = {};
  StepDetector _detector = StepDetector();
  StreamSubscription<AccelerometerEvent>? _sub;

  int _goal = defaultGoal;
  bool _loaded = false;
  bool _tracking = false;
  bool _sensorUnavailable = false;
  bool _disposed = false;
  int _unsaved = 0;

  int get goal => _goal;
  bool get loaded => _loaded;
  bool get tracking => _tracking;
  bool get sensorUnavailable => _sensorUnavailable;

  /// Steps for the current calendar day.
  int get steps => _days[dayKey(DateTime.now())] ?? 0;

  @override
  void notifyListeners() {
    if (!_disposed) super.notifyListeners();
  }

  Future<void> load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_key);
      if (raw != null) {
        final data = jsonDecode(raw) as Map<String, dynamic>;
        _goal = (data['goal'] as num?)?.toInt() ?? defaultGoal;
        final days = (data['days'] as Map<String, dynamic>?) ?? {};
        _days
          ..clear()
          ..addAll(days.map((k, v) => MapEntry(k, (v as num).toInt())));
      }
    } catch (_) {
      // Storage problems should never stop the app from opening.
    }
    _loaded = true;
    notifyListeners();
  }

  Future<void> saveNow() async {
    _unsaved = 0;
    try {
      if (_days.length > _daysToKeep) {
        final keys = _days.keys.toList()..sort();
        for (final k in keys.take(_days.length - _daysToKeep)) {
          _days.remove(k);
        }
      }
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_key, jsonEncode({'goal': _goal, 'days': _days}));
    } catch (_) {}
  }

  void start() {
    if (_tracking || _disposed) return;
    _detector = StepDetector();
    try {
      _sub = _sensorStream().listen(
        (e) {
          final now = DateTime.now().millisecondsSinceEpoch;
          if (_detector.process(e.x, e.y, e.z, now)) addSteps(1);
        },
        onError: (_) {
          _sensorUnavailable = true;
          _tracking = false;
          notifyListeners();
        },
      );
      _tracking = true;
      _sensorUnavailable = false;
    } catch (_) {
      _sensorUnavailable = true;
      _tracking = false;
    }
    notifyListeners();
  }

  void pause() {
    _sub?.cancel();
    _sub = null;
    _tracking = false;
    notifyListeners();
    saveNow();
  }

  void addSteps(int n) {
    final key = dayKey(DateTime.now());
    _days[key] = (_days[key] ?? 0) + n;
    _unsaved += n;
    if (_unsaved >= 10) saveNow();
    notifyListeners();
  }

  void reset() {
    _days[dayKey(DateTime.now())] = 0;
    notifyListeners();
    saveNow();
  }

  void setGoal(int goal) {
    _goal = goal;
    notifyListeners();
    saveNow();
  }

  /// The last [count] days, newest first (index 0 is today).
  List<DayRecord> history(int count) {
    final now = DateTime.now();
    return [
      for (var i = 0; i < count; i++)
        () {
          final date = DateTime(now.year, now.month, now.day - i);
          return DayRecord(
            date: date,
            steps: _days[dayKey(date)] ?? 0,
            isToday: i == 0,
          );
        }(),
    ];
  }

  @override
  void dispose() {
    _sub?.cancel();
    saveNow();
    _disposed = true;
    super.dispose();
  }
}

/// Makes the store available to the whole widget tree and rebuilds
/// dependants whenever it changes.
class StepScope extends InheritedNotifier<StepStore> {
  const StepScope({
    super.key,
    required StepStore store,
    required super.child,
  }) : super(notifier: store);

  static StepStore of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<StepScope>();
    assert(scope != null, 'No StepScope found in the widget tree');
    return scope!.notifier!;
  }
}
