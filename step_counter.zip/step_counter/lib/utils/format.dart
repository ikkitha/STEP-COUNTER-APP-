/// Average walking stride in metres and energy use per step, used for the
/// distance and calorie estimates. Tweak these to calibrate for one person.
const double kStrideMeters = 0.762;
const double kKcalPerStep = 0.04;

double stepsToKm(int steps) => steps * kStrideMeters / 1000;

double stepsToKcal(int steps) => steps * kKcalPerStep;

/// 12345 -> "12,345"
String formatNumber(int n) {
  final s = n.toString();
  final buf = StringBuffer();
  for (var i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) buf.write(',');
    buf.write(s[i]);
  }
  return buf.toString();
}

/// Storage key for a calendar day, e.g. "2026-10-28".
String dayKey(DateTime d) =>
    '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

const List<String> kWeekdayNames = [
  'Mon',
  'Tue',
  'Wed',
  'Thu',
  'Fri',
  'Sat',
  'Sun',
];
