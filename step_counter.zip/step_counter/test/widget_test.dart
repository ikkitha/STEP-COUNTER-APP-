import 'package:flutter_test/flutter_test.dart';
import 'package:sensors_plus/sensors_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:step_counter/main.dart';
import 'package:step_counter/state/step_store.dart';

void main() {
  testWidgets('shows the title, the goal and a Pause button', (tester) async {
    SharedPreferences.setMockInitialValues({});
    final store = StepStore(
      sensorStream: () => Stream<AccelerometerEvent>.empty(),
    );

    await tester.pumpWidget(StepCounterApp(store: store));
    await tester.pumpAndSettle();

    expect(find.text('Step Counter'), findsOneWidget);
    expect(find.text('of 6,000 steps'), findsOneWidget);
    expect(find.text('Pause'), findsOneWidget);
  });
}
