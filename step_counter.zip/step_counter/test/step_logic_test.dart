import 'dart:math';

import 'package:flutter_test/flutter_test.dart';
import 'package:sensors_plus/sensors_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:step_counter/services/step_detector.dart';
import 'package:step_counter/state/step_store.dart';

/// Simulates a phone bouncing at [freq] steps per second for [seconds].
int countSteps({
  required double freq,
  required double amp,
  required double seconds,
}) {
  final detector = StepDetector();
  const hz = 50;
  // Phone held tilted, so gravity is spread over all three axes.
  final norm = sqrt(3.0 * 3.0 + 2.0 * 2.0 + 9.2 * 9.2);
  var steps = 0;
  for (var i = 0; i < seconds * hz; i++) {
    final a = 9.8 + amp * sin(2 * pi * freq * i / hz);
    final nowMs = i * 1000 ~/ hz;
    if (detector.process(3.0 / norm * a, 2.0 / norm * a, 9.2 / norm * a, nowMs)) {
      steps++;
    }
  }
  return steps;
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('StepDetector', () {
    test('counts nothing while the phone is still', () {
      expect(countSteps(freq: 0, amp: 0, seconds: 30), 0);
    });

    test('counts normal walking (2 steps/s) accurately', () {
      expect(countSteps(freq: 2, amp: 3, seconds: 30), inInclusiveRange(55, 65));
    });

    test('ignores tiny fidgeting', () {
      expect(countSteps(freq: 2, amp: 0.5, seconds: 30), 0);
    });
  });

  group('StepStore', () {
    test('adds steps to today, shows them in history and resets', () async {
      SharedPreferences.setMockInitialValues({});
      final store = StepStore(
        sensorStream: () => Stream<AccelerometerEvent>.empty(),
      );
      await store.load();

      store.addSteps(25);
      expect(store.steps, 25);
      expect(store.history(7).first.steps, 25);
      expect(store.history(7).length, 7);

      store.reset();
      expect(store.steps, 0);
      store.dispose();
    });
  });
}
